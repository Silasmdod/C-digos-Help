package Application;

import java.util.Locale;
import java.util.Scanner;

public class Program {
	public static void main(String[] ags) {
		Locale.setDefault(Locale.US);
		Scanner sc = new Scanner(System.in);
		
		sc.close();
	}
	
	
}
