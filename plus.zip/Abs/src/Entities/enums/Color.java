package Entities.enums;

public enum Color {
	BLACK, 
	BLU, 
	RED;

}
