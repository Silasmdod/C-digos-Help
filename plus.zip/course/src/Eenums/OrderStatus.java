package Eenums;

public enum OrderStatus {
	AGUARDANDO_PAGAMENTO,
	PROCESSANDO,
	ENVIANDO,
	ENTREGUE;

}
