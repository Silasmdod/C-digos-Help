package worker;

public class addContract {
	public addContract() {}

}
