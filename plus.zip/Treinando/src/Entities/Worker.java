package Entities;

public class Worker {
	
	public Worker() {}

	public Worker(String workerNome, String valueOf, String baseSalary, Department department) {
		// TODO Auto-generated constructor stub
	}

}
