package Entities.enums;

public enum WorkerLevel {
	JUNIOR,
	MID_LEVEL,
	SENIOR;

}
