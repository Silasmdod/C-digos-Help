package Entities;

public class Department {
	private String name;
	
	
	//Constructors
	
	public Department() {
		
	}

	
	public Department(String name) {
		this.name = name;
	}

	//GGAS
	
	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	
	
	
	
}
